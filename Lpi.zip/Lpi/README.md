###LPI open source ###LPI Smart Contract Open Source Code # # # # # # This Update LPI Contract All Open Source Code ### #20230607 Update # This Update will update the Block Wallet Native APP Source Code and GETH Call Method This will be a long-term process. If you need to use this source code, please note that the original # # Technical Team will not provide technical support and safety maintenance for projects other than GNG Project, please use this open source cautiously # #//ByGGER 





# LPI
###LPI open source ###LPI智能合约开源代码### 
###本次更新LPI合约全部开源代码###
#20230201更新#本次将更新区块钱包原生APP源码以及GETH调用方式 这将是一个长期过程，如需使用本源码，请各位开发者注释原创
另
##技术团队不会为LPI项目以外的项目提供技术支持以及安全维护，请慎重使用本开源
